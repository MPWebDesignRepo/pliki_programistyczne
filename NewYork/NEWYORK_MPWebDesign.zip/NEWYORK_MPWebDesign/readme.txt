Strona internetowa prezentujaca wycieczki oraz formularz kontaktowy, kod oparty na HTML oraz CSS. 
Strona NEWYORK jest tylko czescia pelnej wersji strony www. Probka kodu HTML plus CSS.

Napisany kod nie kodem aplikacji przeznaczonym do wyswietlania na urzedzeniach mobilnych czy tabletach.

Instrukcja do uruchomienia:
1. Pobranie plikow strony zawartych w folderze lub przeniesienie do odpowiedniego katalogu.
2. Uruchomienie programu Visual Studio Code.
3. Otworzenie w progrmie Visual Studio Code folderu z plikami strony.
4. Otworzenie w przegladarce pliku o nazwie "index.html" . 



Pozdrawiam!
MP WebDesigner